# NiTi Elastocaloric Refrigeration SCADA / HMI

A Streamlit research application for an **idealized, lumped-parameter, physics-based simulation** of a NiTi elastocaloric refrigeration cycle. It calculates coupled mechanical, thermal, air-side heat-transfer, chamber, energy, COP, target and safety values without generating random dashboard data.

## Run locally or from GitHub

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py --server.port 5000
```

The Streamlit entry point is `app.py`. The `niti_elastocaloric/` package contains the physics and data layers, so future load-cell, encoder, thermocouple, flow-meter and DAQ adapters can replace the experiment import boundary without changing the dashboard.

## Pages

- **Dashboard / Control** — live calculated readings, reset, phase stepping, single-cycle control, and full simulation.
- **Configuration** — editable material, geometry, air, chamber and simulation inputs plus traceable equations.
- **Live Trends / Cycle Analysis** — time-resolved and cycle-resolved Plotly charts.
- **Target Analysis** — target status is shown on the dashboard and recorded once when `T_chamber <= T_target`.
- **Experiment** — import measured CSV/XLSX data while keeping it separate from simulation data.
- **Simulation vs Experiment** — interpolation-based comparison with MAE/RMSE.
- **Safety** — stress, strain, temperature, fatigue, geometry and target warnings.
- **Data** — CSV and four-sheet Excel export.
- **Parameter Study** — sweeps and user-selected candidate sorting.

## Model equations

SI units are used internally:

```text
A = π/4 (OD² − ID²)
V = A_total × L
m = ρV
C = m Cp
ΔL = εL
F = σA
ξ = clamp(ε / ε_tr, 0, 1)
ΔT_ad ≈ T ΔS ξ / Cp
Q̇_air = ṁ Cp (T_in − T_out)
W_mech = ∫ F dx
C_ch dT_ch/dt = UA(T_amb − T_ch) − Q_useful
COP = Q_cooling / W_input
```

The default exchanger is finned forced air. No water is used in the default configuration. The material values are editable reference values, not guarantees of experimental performance.

## Validation

Run the lightweight physics checks with:

```bash
python -m pytest tests
```

The model is not a substitute for material characterization or laboratory validation. Detailed hysteresis, contact resistance, fluid distribution, actuator dynamics and sensor uncertainty are intentionally outside this lumped model.