"""Physics and data services for the NiTi elastocaloric SCADA/HMI."""

from .model import (
    Config,
    Material,
    SimulationResult,
    available_materials,
    build_config,
    run_simulation,
)

__all__ = [
    "Config",
    "Material",
    "SimulationResult",
    "available_materials",
    "build_config",
    "run_simulation",
]