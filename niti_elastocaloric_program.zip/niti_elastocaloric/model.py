"""Idealized lumped-parameter elastocaloric model.

All geometry is stored in metres, stress in pascals, temperature in kelvin
inside the solver, and time in seconds. Display conversion happens at the
data boundary.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
from math import pi
from typing import Any, Iterable

import pandas as pd


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


@dataclass(frozen=True)
class Material:
    name: str
    density_kg_m3: float
    cp_j_kgk: float
    entropy_j_kgk: float
    transformation_strain: float
    reference_stress_mpa: float
    reference_temp_c: float
    cc_slope_mpa_k: float
    hysteresis_mpa: float
    stress_limit_mpa: float
    af_c: float
    fatigue_cycles: int


MATERIALS: dict[str, Material] = {
    "NiTi": Material("NiTi / Nitinol", 6450, 470, 40, 0.055, 420, 25, 6.5, 160, 800, -5, 100_000),
    "Cu-Al-Ni": Material("Cu-Al-Ni", 7100, 400, 22, 0.045, 180, 25, 2.2, 45, 350, 5, 20_000),
    "Fe-Mn-Si": Material("Fe-Mn-Si", 7200, 520, 12, 0.03, 280, 25, 1.6, 140, 600, 20, 500_000),
    "Natural Rubber": Material("Natural Rubber", 950, 1900, 28, 3.0, 3, 25, 0.02, 1.2, 18, -60, 1_000_000),
}


def available_materials() -> dict[str, Material]:
    """Return the editable reference-material database."""
    return dict(MATERIALS)


class Phase(str, Enum):
    LOAD = "LOAD"
    REJECT_HEAT = "REJECT HEAT"
    UNLOAD = "UNLOAD"
    ABSORB_HEAT = "ABSORB HEAT"


PHASES = (Phase.LOAD, Phase.REJECT_HEAT, Phase.UNLOAD, Phase.ABSORB_HEAT)


@dataclass(frozen=True)
class Geometry:
    form: str = "Tube"
    n_elements: int = 5
    od_m: float = 0.012
    id_m: float = 0.010
    length_m: float = 0.150

    @property
    def cross_section_m2(self) -> float:
        if self.form == "Wire":
            return pi * (self.od_m / 2) ** 2
        return pi / 4 * (self.od_m**2 - self.id_m**2)

    @property
    def total_area_m2(self) -> float:
        return self.cross_section_m2 * self.n_elements

    @property
    def volume_m3(self) -> float:
        return self.total_area_m2 * self.length_m

    @property
    def wall_thickness_mm(self) -> float:
        return self.od_m * 1000 / 2 if self.form == "Wire" else (self.od_m - self.id_m) * 1000 / 2

    @property
    def wetted_area_m2(self) -> float:
        perimeter = pi * self.od_m if self.form == "Tube" else pi * self.od_m
        return perimeter * self.length_m * self.n_elements


@dataclass(frozen=True)
class Config:
    material_key: str = "NiTi"
    geometry: Geometry = field(default_factory=Geometry)
    max_strain: float = 0.055
    phase_time_s: float = 5.0
    actuator_efficiency: float = 0.85
    ambient_c: float = 25.0
    target_c: float = 10.0
    chamber_capacity_j_k: float = 800.0
    insulation_ua_w_k: float = 0.35
    air_flow_cfm: float = 50.0
    air_density_kg_m3: float = 1.184
    air_cp_j_kgk: float = 1005.0
    h_w_m2k: float = 620.0
    exchanger: str = "Finned forced air"
    n_cycles: int = 40
    dt_s: float = 0.5
    substeps: int = 1
    fan_power_w: float = 45.0
    safe_min_c: float = -30.0
    safe_max_c: float = 80.0

    @property
    def material(self) -> Material:
        return MATERIALS[self.material_key]

    @property
    def geometry_mass_kg(self) -> float:
        return self.geometry.volume_m3 * self.material.density_kg_m3

    @property
    def thermal_capacity_j_k(self) -> float:
        return self.geometry_mass_kg * self.material.cp_j_kgk

    @property
    def air_flow_m3_s(self) -> float:
        return self.air_flow_cfm * 0.00047194745

    @property
    def air_mass_flow_kg_s(self) -> float:
        return self.air_density_kg_m3 * self.air_flow_m3_s

    @property
    def fixed_target_is_valid(self) -> bool:
        return self.target_c < self.ambient_c

    def as_dict(self) -> dict[str, Any]:
        result = asdict(self)
        result["geometry"] = asdict(self.geometry)
        result["material"] = self.material.name
        result["geometry_mass_kg"] = self.geometry_mass_kg
        result["thermal_capacity_j_k"] = self.thermal_capacity_j_k
        result["air_mass_flow_kg_s"] = self.air_mass_flow_kg_s
        return result


def build_config(**kwargs: Any) -> Config:
    """Build and validate a configuration from UI or API values."""
    geometry = kwargs.pop("geometry", None)
    if geometry is None:
        geometry = Geometry(
            form=str(kwargs.pop("form", "Tube")),
            n_elements=int(kwargs.pop("n_elements", 5)),
            od_m=float(kwargs.pop("od_mm", 12)) / 1000,
            id_m=float(kwargs.pop("id_mm", 10)) / 1000,
            length_m=float(kwargs.pop("length_mm", 150)) / 1000,
        )
    material_key = str(kwargs.pop("material_key", "NiTi"))
    if material_key not in MATERIALS:
        raise ValueError("Unknown material.")
    if geometry.n_elements < 1 or geometry.length_m <= 0 or geometry.od_m <= 0:
        raise ValueError("Invalid geometry: dimensions and element count must be positive.")
    if geometry.form == "Tube" and geometry.id_m >= geometry.od_m:
        raise ValueError("Invalid geometry: ID must be smaller than OD.")
    if geometry.form == "Tube" and geometry.id_m < 0:
        raise ValueError("Invalid geometry: ID must be non-negative.")
    max_strain = float(kwargs.pop("max_strain", MATERIALS[material_key].transformation_strain))
    if max_strain < 0:
        raise ValueError("Invalid strain: value must be non-negative.")
    air_flow = float(kwargs.get("air_flow_cfm", 50))
    if air_flow <= 0:
        raise ValueError("Invalid airflow: flow must be greater than zero.")
    target = float(kwargs.get("target_c", 10))
    ambient = float(kwargs.get("ambient_c", 25))
    if target >= ambient:
        raise ValueError("Invalid target: target must be below ambient for cooling mode.")
    return Config(material_key=material_key, geometry=geometry, max_strain=max_strain, **kwargs)


@dataclass
class SolverState:
    time_s: float
    cycle: int
    phase_index: int
    phase_time_s: float
    chamber_k: float
    element_k: float
    target_reached: bool = False
    target_time_s: float | None = None
    target_cycle: int | None = None
    target_phase: str | None = None
    cooling_energy_j: float = 0.0
    mechanical_work_j: float = 0.0
    fan_energy_j: float = 0.0
    previous_strain: float = 0.0
    last_reading: dict[str, Any] | None = None

    @property
    def phase(self) -> Phase:
        return PHASES[self.phase_index]


@dataclass
class SimulationResult:
    readings: pd.DataFrame
    cycle_summary: pd.DataFrame
    state: SolverState
    config: Config


def initial_state(config: Config) -> SolverState:
    ambient_k = config.ambient_c + 273.15
    return SolverState(0.0, 0, 0, 0.0, ambient_k, ambient_k)


class PhysicsEngine:
    """Single-step numerical integrator used by batch and interactive modes."""

    def __init__(self, config: Config, state: SolverState | None = None):
        self.config = config
        self.state = state or initial_state(config)

    def _mechanical(self, strain: float) -> tuple[float, float, float, float]:
        m = self.config.material
        temp_c = self.state.element_k - 273.15
        transformation = clamp(strain / max(m.transformation_strain, 1e-12), 0, 1)
        thermal_shift = m.cc_slope_mpa_k * (temp_c - m.reference_temp_c)
        hysteresis = m.hysteresis_mpa if self.state.phase in (Phase.LOAD, Phase.REJECT_HEAT) else -m.hysteresis_mpa
        stress_mpa = max(0.0, m.reference_stress_mpa + thermal_shift + hysteresis * transformation)
        force_n = stress_mpa * 1e6 * self.config.geometry.total_area_m2
        displacement_mm = strain * self.config.geometry.length_m * 1000
        return transformation, stress_mpa, force_n, displacement_mm

    def step(self) -> dict[str, Any]:
        c = self.config
        s = self.state
        phase = s.phase
        dt = c.dt_s / max(c.substeps, 1)
        old_strain = s.previous_strain
        phase_fraction = clamp(s.phase_time_s / max(c.phase_time_s, dt), 0, 1)
        if phase == Phase.LOAD:
            strain = c.max_strain * clamp(phase_fraction + dt / c.phase_time_s, 0, 1)
        elif phase == Phase.REJECT_HEAT:
            strain = c.max_strain
        elif phase == Phase.UNLOAD:
            strain = c.max_strain * (1 - clamp(phase_fraction + dt / c.phase_time_s, 0, 1))
        else:
            strain = 0.0
        transformation, stress_mpa, force_n, displacement_mm = self._mechanical(strain)

        # Elastocaloric temperature follows the strain increment, not a hard-coded jump.
        strain_delta = transformation - clamp(old_strain / max(c.material.transformation_strain, 1e-12), 0, 1)
        if phase == Phase.LOAD:
            s.element_k += max(s.element_k, 1.0) * c.material.entropy_j_kgk * max(strain_delta, 0) / c.material.cp_j_kgk
        elif phase == Phase.UNLOAD:
            s.element_k -= max(s.element_k, 1.0) * c.material.entropy_j_kgk * max(-strain_delta, 0) / c.material.cp_j_kgk

        air_in_c = c.ambient_c if phase in (Phase.REJECT_HEAT, Phase.ABSORB_HEAT) else s.chamber_k - 273.15
        air_out_c = air_in_c
        air_heat_w = 0.0
        cooling_w = 0.0
        heat_rejected_w = 0.0
        if phase == Phase.REJECT_HEAT:
            air_heat_w = c.h_w_m2k * c.geometry.wetted_area_m2 * ((s.element_k - 273.15) - air_in_c)
            s.element_k -= air_heat_w * dt / max(c.thermal_capacity_j_k, 1e-9)
            air_out_c = air_in_c + air_heat_w / max(c.air_mass_flow_kg_s * c.air_cp_j_kgk, 1e-9)
            heat_rejected_w = max(air_heat_w, 0.0)
        elif phase == Phase.ABSORB_HEAT:
            conductance = c.h_w_m2k * c.geometry.wetted_area_m2
            cooling_w = max(conductance * ((s.chamber_k - 273.15) - (s.element_k - 273.15)), 0.0)
            cooling_w = min(cooling_w, max(c.chamber_capacity_j_k, 1) * 2 / max(dt, 1e-9))
            s.element_k += cooling_w * dt / max(c.thermal_capacity_j_k, 1e-9)
            air_out_c = (s.chamber_k - 273.15) - cooling_w / max(c.air_mass_flow_kg_s * c.air_cp_j_kgk, 1e-9)

        chamber_leak_w = c.insulation_ua_w_k * (c.ambient_c - (s.chamber_k - 273.15))
        chamber_load_w = cooling_w if phase == Phase.ABSORB_HEAT else 0.0
        s.chamber_k += (chamber_leak_w - chamber_load_w) * dt / max(c.chamber_capacity_j_k, 1e-9)
        displacement_delta_m = abs(strain - old_strain) * c.geometry.length_m
        mechanical_work = max(force_n * displacement_delta_m, 0.0)
        mechanical_power = mechanical_work / max(dt, 1e-9)
        fan_power = c.fan_power_w if phase in (Phase.REJECT_HEAT, Phase.ABSORB_HEAT) else 0.0
        s.cooling_energy_j += cooling_w * dt
        s.mechanical_work_j += mechanical_work
        s.fan_energy_j += fan_power * dt

        s.time_s += dt
        s.phase_time_s += dt
        if s.chamber_k - 273.15 <= c.target_c and not s.target_reached:
            s.target_reached = True
            s.target_time_s = s.time_s
            s.target_cycle = s.cycle
            s.target_phase = phase.value

        if s.phase_time_s >= c.phase_time_s - 1e-9:
            s.phase_time_s = 0.0
            if s.phase_index == len(PHASES) - 1:
                s.phase_index = 0
                s.cycle += 1
            else:
                s.phase_index += 1
        s.previous_strain = strain

        total_input = s.mechanical_work_j / max(c.actuator_efficiency, 1e-9) + s.fan_energy_j
        cop = s.cooling_energy_j / total_input if total_input > 0 else 0.0
        record = {
            "time_s": s.time_s,
            "cycle": s.cycle,
            "phase": phase.value,
            "phase_time_s": max(s.phase_time_s, 0.0),
            "chamber_c": s.chamber_k - 273.15,
            "element_c": s.element_k - 273.15,
            "air_in_c": air_in_c,
            "air_out_c": air_out_c,
            "ambient_c": c.ambient_c,
            "target_c": c.target_c,
            "strain_pct": strain * 100,
            "stress_mpa": stress_mpa,
            "force_n": force_n,
            "displacement_mm": displacement_mm,
            "cooling_w": cooling_w,
            "heat_rejected_w": heat_rejected_w,
            "cooling_energy_j": s.cooling_energy_j,
            "mechanical_work_j": s.mechanical_work_j,
            "mechanical_power_w": mechanical_power,
            "fan_energy_j": s.fan_energy_j,
            "input_energy_j": total_input,
            "air_mass_flow_kg_s": c.air_mass_flow_kg_s,
            "cop": cop,
            "target_reached": s.target_reached,
        }
        s.last_reading = record
        return record


def run_simulation(config: Config, max_records: int | None = None) -> SimulationResult:
    engine = PhysicsEngine(config)
    records: list[dict[str, Any]] = []
    steps_per_cycle = max(1, int(round(config.phase_time_s / config.dt_s))) * len(PHASES)
    total_steps = steps_per_cycle * config.n_cycles
    if max_records is not None:
        total_steps = min(total_steps, max_records)
    for _ in range(total_steps):
        records.append(engine.step())
    frame = pd.DataFrame(records)
    return SimulationResult(frame, summarize_cycles(frame), engine.state, config)


def summarize_cycles(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return pd.DataFrame()
    rows: list[dict[str, Any]] = []
    cycle_values = sorted(frame["cycle"].dropna().unique())
    for cycle in cycle_values:
        part = frame[frame["cycle"] == cycle]
        if part.empty:
            continue
        rows.append(
            {
                "cycle": int(cycle),
                "max_temperature_c": float(part["element_c"].max()),
                "min_temperature_c": float(part["element_c"].min()),
                "chamber_c": float(part["chamber_c"].iloc[-1]),
                "max_stress_mpa": float(part["stress_mpa"].max()),
                "max_strain_pct": float(part["strain_pct"].max()),
                "cooling_energy_j": float(part["cooling_energy_j"].iloc[-1]),
                "average_cooling_power_w": float(part["cooling_w"].mean()),
                "mechanical_work_j": float(part["mechanical_work_j"].iloc[-1]),
                "input_energy_j": float(part["input_energy_j"].iloc[-1]),
                "cop": float(part["cop"].iloc[-1]),
            }
        )
    return pd.DataFrame(rows)


def active_alarms(config: Config, state: SolverState | None = None) -> list[tuple[str, str]]:
    s = state or initial_state(config)
    reading = s.last_reading or {}
    alarms: list[tuple[str, str]] = []
    stress = float(reading.get("stress_mpa", 0))
    temp = float(reading.get("element_c", config.ambient_c))
    strain_pct = float(reading.get("strain_pct", 0))
    if abs(stress) > config.material.stress_limit_mpa:
        alarms.append(("ALARM", "STRESS LIMIT EXCEEDED"))
    if strain_pct / 100 > config.material.transformation_strain * 1.15:
        alarms.append(("ALARM", "EXCESSIVE STRAIN"))
    if temp < config.safe_min_c or temp > config.safe_max_c:
        alarms.append(("ALARM", "TEMPERATURE LIMIT"))
    if s.cycle >= config.material.fatigue_cycles:
        alarms.append(("WARNING", "INDICATIVE FATIGUE LIFE EXCEEDED"))
    if config.geometry.wall_thickness_mm < 0.5:
        alarms.append(("WARNING", "LOW WALL THICKNESS"))
    if config.target_c <= config.material.af_c:
        alarms.append(("ENGINEERING", "TARGET IS AT OR BELOW MATERIAL Af"))
    return alarms


def geometry_table(config: Config) -> pd.DataFrame:
    g = config.geometry
    return pd.DataFrame(
        [
            ("Cross-sectional area / element", g.cross_section_m2, "m²"),
            ("Total cross-sectional area", g.total_area_m2, "m²"),
            ("Volume", g.volume_m3, "m³"),
            ("Mass", config.geometry_mass_kg, "kg"),
            ("Thermal capacity", config.thermal_capacity_j_k, "J/K"),
            ("Wetted surface area", g.wetted_area_m2, "m²"),
            ("Wall thickness", g.wall_thickness_mm, "mm"),
            ("Air mass flow", config.air_mass_flow_kg_s, "kg/s"),
        ],
        columns=["Property", "Value", "Unit"],
    )


def config_frame(config: Config) -> pd.DataFrame:
    return pd.DataFrame(list(config.as_dict().items()), columns=["Setting", "Value"])


def run_parameter_sweep(base: Config, parameter: str, values: Iterable[float | str]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for value in values:
        try:
            kwargs: dict[str, Any] = {}
            if parameter == "Material":
                kwargs["material_key"] = str(value)
            elif parameter == "Number of elements":
                kwargs["geometry"] = Geometry(
                    base.geometry.form, int(float(value)), base.geometry.od_m, base.geometry.id_m, base.geometry.length_m
                )
            elif parameter == "Strain (%)":
                kwargs["max_strain"] = float(value) / 100
            elif parameter == "Air flow (CFM)":
                kwargs["air_flow_cfm"] = float(value)
            elif parameter == "Heat transfer coefficient":
                kwargs["h_w_m2k"] = float(value)
            elif parameter == "Phase time (s)":
                kwargs["phase_time_s"] = float(value)
            elif parameter == "Target (°C)":
                kwargs["target_c"] = float(value)
            config = build_config(**{**base.__dict__, **kwargs})
            result = run_simulation(config)
            frame = result.readings
            rows.append(
                {
                    "Material": config.material.name,
                    "Value": value,
                    "Minimum chamber °C": float(frame["chamber_c"].min()) if not frame.empty else None,
                    "Time to target (s)": result.state.target_time_s,
                    "Cycles to target": result.state.target_cycle,
                    "Cooling power (W)": float(frame["cooling_w"].max()) if not frame.empty else None,
                    "COP": float(frame["cop"].iloc[-1]) if not frame.empty else None,
                    "Reachable": result.state.target_reached,
                }
            )
        except (ValueError, KeyError):
            continue
    return pd.DataFrame(rows)