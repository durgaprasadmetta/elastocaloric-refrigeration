"""Import and export helpers for measured and calculated data."""

from __future__ import annotations

from io import BytesIO
from typing import Any

import pandas as pd

from .model import Config, SimulationResult, config_frame


REQUIRED_COLUMNS = ["time_s", "chamber_c", "element_c", "air_in_c", "air_out_c"]


def import_experiment(uploaded_file: Any) -> pd.DataFrame:
    name = getattr(uploaded_file, "name", "").lower()
    if name.endswith((".xlsx", ".xls")):
        frame = pd.read_excel(uploaded_file)
    else:
        frame = pd.read_csv(uploaded_file)
    frame.columns = [str(col).strip() for col in frame.columns]
    missing = [col for col in REQUIRED_COLUMNS if col not in frame.columns]
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(missing)}")
    for column in frame.columns:
        if column not in {"phase"}:
            frame[column] = pd.to_numeric(frame[column], errors="coerce")
    return frame.dropna(subset=["time_s"]).reset_index(drop=True)


def csv_bytes(frame: pd.DataFrame) -> bytes:
    return frame.to_csv(index=False).encode("utf-8")


def excel_bytes(result: SimulationResult) -> bytes:
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        result.readings.to_excel(writer, index=False, sheet_name="Time History")
        result.cycle_summary.to_excel(writer, index=False, sheet_name="Cycle Summary")
        config_frame(result.config).to_excel(writer, index=False, sheet_name="Configuration")
        target = pd.DataFrame(
            [
                ("Ambient", result.config.ambient_c, "°C"),
                ("Target", result.config.target_c, "°C"),
                ("Time to target", result.state.target_time_s, "s"),
                ("Cycles to target", result.state.target_cycle, "cycle"),
                ("Minimum chamber temperature", result.readings["chamber_c"].min() if not result.readings.empty else None, "°C"),
                ("Target reached", result.state.target_reached, ""),
            ],
            columns=["Metric", "Value", "Unit"],
        )
        target.to_excel(writer, index=False, sheet_name="Target Performance")
    return output.getvalue()


def compare_frames(simulation: pd.DataFrame, experiment: pd.DataFrame, metrics: list[str]) -> tuple[pd.DataFrame, pd.DataFrame]:
    if simulation.empty or experiment.empty:
        return pd.DataFrame(), pd.DataFrame()
    exp = experiment.sort_values("time_s").drop_duplicates("time_s")
    sim = simulation.sort_values("time_s")
    joined = pd.DataFrame({"time_s": exp["time_s"].to_numpy()})
    for metric in metrics:
        if metric not in sim.columns or metric not in exp.columns:
            continue
        joined[f"{metric}_simulation"] = pd.Series(
            pd.Series(sim[metric].to_numpy(), index=sim["time_s"]).reindex(exp["time_s"]).interpolate().ffill().bfill().to_numpy()
        )
        joined[f"{metric}_experimental"] = exp[metric].to_numpy()
        joined[f"{metric}_absolute_error"] = (joined[f"{metric}_simulation"] - joined[f"{metric}_experimental"]).abs()
    summary_rows = []
    for metric in metrics:
        error_col = f"{metric}_absolute_error"
        if error_col not in joined:
            continue
        error = joined[error_col].dropna()
        summary_rows.append(
            {
                "Metric": metric,
                "MAE": float(error.mean()) if not error.empty else None,
                "RMSE": float((error.pow(2).mean()) ** 0.5) if not error.empty else None,
                "Maximum absolute error": float(error.max()) if not error.empty else None,
            }
        )
    return joined, pd.DataFrame(summary_rows)