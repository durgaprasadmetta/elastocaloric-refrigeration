import math

from niti_elastocaloric.model import Geometry, build_config, run_simulation


def test_tube_geometry():
    geometry = Geometry("Tube", 5, 0.012, 0.010, 0.150)
    expected_area = math.pi / 4 * (0.012**2 - 0.010**2)
    assert math.isclose(geometry.cross_section_m2, expected_area)
    assert geometry.volume_m3 > 0


def test_mechanics_and_target_fields_are_physical():
    config = build_config(n_cycles=2, dt_s=0.5)
    result = run_simulation(config)
    assert not result.readings.empty
    assert (result.readings["force_n"] >= 0).all()
    assert (result.readings["strain_pct"] >= 0).all()
    assert result.readings["time_s"].is_monotonic_increasing


def test_four_phase_cycle_is_recorded():
    config = build_config(n_cycles=1, dt_s=0.5)
    result = run_simulation(config)
    assert set(result.readings["phase"]) == {"LOAD", "REJECT HEAT", "UNLOAD", "ABSORB HEAT"}


def test_target_record_is_not_overwritten():
    config = build_config(n_cycles=3, dt_s=0.5, target_c=24.9, chamber_capacity_j_k=1)
    result = run_simulation(config)
    assert result.state.target_reached
    first = result.state.target_time_s
    assert first is not None
    assert result.readings[result.readings["target_reached"]]["time_s"].min() == first